<template>
  <div>
    <img src="../assets/maintenance.jpg" width="400" />
    <h1>시스템 점검 중</h1>
    <h2>2020.09.15 <span>08:00</span> ~ 2020.09.16 <span>20:00</span></h2>
  </div>
</template>

<script>
export default {
  name: "SystemMaintenance",
  props: {}
};
</script>

<style>
span {
  color: grey;
}
</style>
